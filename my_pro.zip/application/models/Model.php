<?php
class Model extends CI_Model 
{
	function contacts_us($post_data)
	{
		$data = $this->db->insert('contacts_us', $post_data);
	}
	
	function like_list()
	{
		$this->db->select('user_login.user_name');
		$this->db->from('photo_like');
		$this->db->where('photo_id', $_SESSION['photo_id']);
		$this->db->where('photo_name', $_SESSION['photo_name']);
		$this->db->where('like', 1);
		$this->db->join('user_login', 'user_login.user_id = photo_like.user_id' ,'left');
		$data = $this->db->get()->result_array();
		if($data)
		{
			foreach($data as $datas)
			{
				$like_data[] = $datas['user_name']; 
			}
		}
		else
		{
			$like_data[] = 'Like not Found.';
		}	
		return $like_data;
	}
	
	function check_like()
	{
		$this->db->from('photo_like');
		$this->db->where('user_id', $_SESSION['user_id']);
		$this->db->where('photo_id', $_SESSION['photo_id']);
		$this->db->where('photo_name', $_SESSION['photo_name']);
		$check_like_data = $this->db->get()->result_array();
		return $check_like_data;
	}
	
	function new_like($datas)
	{
		$data = $this->db->insert('photo_like', $datas);
	}
	
	function up_like($datas)
	{
		$this->db->where('user_id', $_SESSION['user_id']);
		$this->db->where('photo_id', $_SESSION['photo_id']);
		$this->db->where('photo_name', $_SESSION['photo_name']);
		$data = $this->db->update('photo_like', $datas);
	}
	
	function comm()
	{
		$this->db->select('user_login.user_id,user_login.user_name,user_login.user_pic,comment.comment_id,comment.comment');
		$this->db->from('comment');
		$this->db->where('photo_id', $_SESSION['photo_id']);
		$this->db->where('photo_name', $_SESSION['photo_name']);
		$this->db->join('user_login', 'user_login.user_id = comment.user_id' ,'left');
		$this->db->order_by('comment_id', 'ASC');
		$comm_data = $this->db->get()->result_array();
		return $comm_data;
	}
	
	function new_comm($data)
	{
		$data = $this->db->insert('comment', $data);
	}
	
	function delete_comm($data)
	{
		$this->db->where('comment_id', $data);
		$this->db->delete('comment'); 
	}
	
	function noti_comm()
	{
		$user = 20;
		
		$sql = "SELECT comment.user_id,comment.photo_id,comment.photo_name,comment.comment,comment.notification,comment.time FROM comment WHERE comment.user_id != ? AND comment.notification IS NOT NULL JOIN user_login user_login.user_id = comment.user_id LEFT ORDER_BY TIME ASC";
		
		$this->db->query($sql, array($user));
		$comm_data = $this->db->get()->result_array();
		return $comm_data;
	}	
}
?>