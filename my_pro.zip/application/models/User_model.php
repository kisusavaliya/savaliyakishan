<?php
class User_model extends CI_Model 
{
	function sign_up($post_data)
	{
		$this->db->insert('user_login', $post_data);
	}
	
	function reset_pass($email,$post_data)
	{
		$this->db->where('user_email='.$email);
		$data = $this->db->update('user_login', $post_data);
	}
	
	function user_info($email)
	{
		$this->db->select('*');
		$this->db->from('user_login');
		$this->db->where($email);
		
		$data = $this->db->get()->row_array();
		return $data;
	}
	
	function user_new_pic($email,$post_data)
	{
		$this->db->where($email);
		$data = $this->db->update('user_login', $post_data);
	}
}
?>