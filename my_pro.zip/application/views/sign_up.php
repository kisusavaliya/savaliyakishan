<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<div class="container">
	<div>	
			<form class="form-horizontal" id="sign_up" action="<?php echo site_url('User/sign_up'); ?>" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label class="error col-sm-offset-2"><?php echo $error; ?></label>
			    </div>
				<div class="form-group">
					<label class="control-label col-sm-2">Name:</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" name="name" id="name" placeholder="Enter your name" value="<?php echo @$_POST['name']; ?>" required>
					  <label class="error"><?php echo form_error('name');?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Nick Name:</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" name="nick_name" id="nick_name" placeholder="Enter your nick name" value="<?php echo @$_POST['nick_name']; ?>" required>
					  <label class="error"><?php echo form_error('nick_name');?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Email:</label>
					<div class="col-sm-10">
					  <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" value="<?php echo @$_POST['email']; ?>" required>
					  <label class="error"><?php echo form_error('email'); ?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Password:</label>
					<div class="col-sm-10"> 
					  <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
					  <label class="error"><?php echo form_error('password');?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Sex:</label>
					<div class="col-sm-10"> 
					  Male <input type="radio" name="sex" value="male" checked="checked" />
					  Femal <input type="radio" name="sex" value="female"  />
					  <label class="error"><?php echo form_error('sex');?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">BOD:</label>
					<div class="col-sm-10"> 
					  <input type="date" class="form-control" name="bod" id="bod" placeholder="Enter your BOD" value="<?php echo $_POST['bod']; ?>" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Phone number:</label>
					<div class="col-sm-10">
					  <input type="phone" class="form-control" name="phone_number" id="phone_number" placeholder="Enter your phone number" value="<?php echo @$_POST['phone_number']; ?>" required>
					  <label class="error"><?php echo form_error('phone_number');?></label>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">Your photo:</label>
					<div class="col-sm-10">
					  <input type="file" class="form-control" name="pic" id="pic" required>
					  <label class="error"><?php echo $pic_error;?></label>
					</div>
				</div>
				<div class="form-group"> 
					<div class="col-sm-offset-2 col-sm-10">
					  <input type="submit" class="btn btn-danger" name="submit" value="Submit">
					  <a href="<?php echo site_url('User');?>"> <input type="button" class="btn btn-danger" name="login" value="Login"></a>
					</div>
				</div>
			</form>
			<script>
				$(document).ready(function()
				{					
					$("#sign_up").validate(
					{
						rules: 
						{
							name:
							{
								required: true,
							},
							nick:
							{
								required: true,
							},
							email:
							{
								required: true,
								email: true
							},
							password:
							{
								required: true,
								password: "required",
								minlength: 6
							},
							sex:
							{
								required: true,
							},
							bod:
							{
								required: true,
							},
							phone_number:
							{
								required: true,
								minlength: 10,
								maxlength: 10,
							},
							pic:
							{
								required: true,
							},
						}
					});
				});			
			</script>
	</div>		 
</div>
<?php $this->load->view('layouts/footer.php'); ?>