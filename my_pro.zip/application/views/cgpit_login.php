<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<form class="form-horizontal" id="main_login" action="<?php echo site_url('D2d'); ?>" method="post">
		<div class="form-group">
			<label class="error col-sm-offset-2"><?php echo $error; echo $_SESSION['Msg']; unset($_SESSION['Msg']); ?></label>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Name:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" value="<?php echo @$name; ?>" required>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Password:</label>
			<div class="col-sm-10">
				<input type="password" class="form-control" name="password" id="password" placeholder="Enter password" value="<?php echo @$password; ?>" required>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit">
			</div>
		</div>
	</form>
	<script>
		$(document).ready(function()
		{					
			$("#main_login").validate(
			{
				rules: 
				{
					name:
					{
						required: true,
					},
					password:
					{
						required: true,
						password: "required",
					},
				}
			});
		});
	</script>	
</div>	
<?php $this->load->view('layouts/footer.php'); ?>