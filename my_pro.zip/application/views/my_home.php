<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<table class="table" width="100%">
	<tr>
    	<td width="50%">
			<a href="<?php echo site_url('Utu'); ?>">  
				<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/utu.jpg'); ?>" width="100%" >
			</a>
		</td>
        <td width="50%">
			<a href="<?php echo site_url('User'); ?>"> 
				<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/my.jpg'); ?>" width="100%" >
			</a>	
		</td>
    </tr>
	<tr> 
		<td> <hr/> </td>
		<td> <hr/> </td>
	</tr>
	<tr>
    	<td width="50%" align="center">
			<a href="<?php echo site_url('Utu'); ?>">
				<h2> Std Page login </h2> </td>
    		</a>
		</td>
        <td width="50%" align="center">
			<a href="<?php echo site_url('User'); ?>"> 
				<h2> My Page Login </h2> 
			</a>
		</td>	
	</tr>
	<tr>
		<td colspan="2"><hr /></td>
	</tr>
	<tr align="center">
		<td colspan="2">
			<a href="https://drive.google.com/open?id=1xvxCa_jbzQE6Xs0E6SYS-wzmW3WRRArx" target="_blank"><img src="<?php echo base_url('file/images/apk.jpg'); ?>" height="50"/></a>
		</td>
	</tr>
	<tr>
		<td colspan="2"><hr /></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<!-- hitwebcounter Code START -->
				<a target="_blank">
				<img src="http://hitwebcounter.com/counter/counter.php?page=6899936&style=0003&nbdigits=5&type=page&initCount=0" title="http://www.hitwebcounter.com/" Alt="http://www.hitwebcounter.com/" border="0" >
               </a>   
		</td>
	</tr>
</table>