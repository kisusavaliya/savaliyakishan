<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<div class="component">
	<!-- Start Nav Structure -->
		<button class="cn-button" id="cn-button">+</button>
		<div class="cn-wrapper" id="cn-wrapper">
			<ul>
				<li <?php if($menu === 'contacts_us'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Utu/contacts_us');?>"><span class="icon-envelope"></span></a></li>
				<li <?php if($menu === 'photos'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Utu/photos');?>"><span class="icon-picture"></span></a></li>
				<li <?php if($menu === 'Home'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Utu');?>"><span class="icon-home"></span></a></li>
				<li <?php if($menu === 'videos'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Utu/videos');?>"><span class="icon-facetime-video"></span></a></li>
				<?php
				if($_SESSION['user_email']){
					echo "<li><a href='#'><span class='icon-signout'></span></a></li>";
				}else{
					if($menu === 'login'){
						echo "<li class='active'><a href='#'><span class='icon-signin'></span></a></li>";	
					}else{
						echo "<li><a href='#'><span class='icon-signin'></span></a></li>";	
					}
				}
				?>
			</ul>
		</div>
		<div id="cn-overlay" class="cn-overlay"></div>
	<!-- End Nav Structure -->
	</div>
	<hr color="red">
	<p class="footer_font">Devloped By:~ Savaliya Kishan </p>
	<table width="100%">
		<tr align="center"> 
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
		</tr> 
	</table>
</div><!-- /container -->	
<div style="height:45px"></div>
<script src="<?php echo base_url('file/js/polyfills.js'); ?>"></script>
<script src="<?php echo base_url('file/js/demo1.js'); ?>"></script>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<!-- For the demo ad only -->   
</body>
</html>