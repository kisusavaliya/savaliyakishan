<?php defined('BASEPATH') OR exit('No direct script access allowed'); error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
	<title> <?php echo $titel; ?> </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="shortcut icon" href="<?php echo base_url('file/images/gt_favicon.png'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/bootstrap1.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/normalize.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/component1.css'); ?>" />
	
	<script type="text/javascript" src="<?php echo base_url('file/js/modernizr-2.6.2.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/jquery.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/bootstrap.js'); ?>"></script>
	<script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
	<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-7243260-2']);
	_gaq.push(['_trackPageview']);
	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
	</script>
<script>
		$(document).ready(function()
		{
			$('[alt="Free Web Hosting"]').hide();	
		});
    </script>	
<script>
	$(document).ready(function()
	{
		$("#freewha").hide();	
	});
	</script>

<style>
body {margin:0;}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }

}
</style>
</head>
<body>
<link rel="stylesheet" href="<?php echo base_url('file/css/jquery.lazyloadxt.spinner.css'); ?>">
<script src="<?php echo base_url('file/js/jquery.lazyloadxt.js') ?>"></script>
<script src="<?php echo base_url('file/js/jquery.session.js') ?>"></script>
<div>
	<div class="heading1">
		<table width="100%">
			<tr align="center"> 
				<td align="center">  
					<img class="heading4" src="<?php echo base_url('file/images/gt_favicon.png'); ?>" height="59" width="59">
				</td>
				<td align="center">
					<a href="<?php echo site_url('Home'); ?>"> <p class="heading3"> Savaliya Kishan </p> </a>
				</td>
				<td align="center">
					<img class="heading4" src="<?php echo base_url('file/images/gt_favicon.png'); ?>" height="59" width="59">
				</td>
			</tr>
		</table>			
	</div>
	<br>	
	<?php 
		$this->load->view('utu_layouts/menu.php'); 
	?>
	<p align="center" class='heading2'> <?php echo $head_titel; ?> </p>