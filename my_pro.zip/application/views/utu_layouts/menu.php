<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<div class="topnav" id="myTopnav">
  <a> Savaliya Kishan </a>
  <a class="<?php if($menu === 'Home') { echo "active"; } ?>" href="<?php echo site_url('Utu/'); ?>">Home</a>
  <a class="<?php if($menu === 'sem_1') { echo "active"; } ?>" href="<?php echo site_url('Utu/sem_1'); ?>">Sem 1</a>
  <a class="<?php if($menu === 'sem_2') { echo "active"; } ?>" href="<?php echo site_url('Utu/sem_2'); ?>">Sem 2</a>
  <a class="<?php if($menu === 'sem_3') { echo "active"; } ?>" href="<?php echo site_url('Utu/sem_3'); ?>">Sem 3</a>
  <a class="<?php if($menu === 'sem_4') { echo "active"; } ?>" href="<?php echo site_url('Utu/sem_4'); ?>">Sem 4</a>
  
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>