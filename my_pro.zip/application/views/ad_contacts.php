<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('ad_layouts/header.php'); ?>
<div class="container">
	<div class="panel-group">
		<div class="panel panel-primary">
			<div class="panel-heading"> Admin Home </div>
			<div class="panel-body">
				<table class="table table-bordered">
					<tr class="header">
						<td> Name </td>
						<td> Email </td>
						<td> Phone </td>
						<td> message </td>
					</tr>
					<?php foreach($datas as $data) { ?>
					<tr>
						<td> <?php echo $data->name; ?> </td>
						<td> <?php echo $data->email;?> </td>
						<td> <?php echo $data->phone;?> </td>
						<td> <?php echo $data->message;?> </td>
					</tr>
					<?php }?> 
				</table>	
			</div>
			<div>
				<?php echo $this->pagination->create_links(); ?> 	
			</div>
		</div>	
	</div>
</div>	

<?php $this->load->view('ad_layouts/footer.php'); ?>