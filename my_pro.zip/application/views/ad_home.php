<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('ad_layouts/header.php'); ?>
<div class="container">
	<div class="panel-group">
		<div class="panel panel-primary">
			<div class="panel-heading"> Admin Home </div>
			<div class="panel-body">
				<table class="table table-bordered">
					<tr class="header">
						<td> Photo </td>
						<td> Name </td>
						<td> Nick Name </td>
						<td> Number </td>
					</tr>
					<?php foreach($datas as $data) { ?>
					<tr>
						<td> <img src="<?php echo base_url() .'file/images/user_photos/'. $data->user_pic; ?>" height="100" width="100"> </td>
						<td> <?php echo $data->user_name;?> </td>
						<td> <?php echo $data->user_nick_name;?> </td>
						<td> <?php echo $data->user_number;?> </td>
					</tr>
					<?php }?> 
				</table>	
			</div>
			<div>
				<?php echo $this->pagination->create_links(); ?> 	
			</div>
		</div>	
	</div>
</div>	

<?php $this->load->view('ad_layouts/footer.php'); ?>