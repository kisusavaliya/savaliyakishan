<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
$_SESSION['user_pic'] = $user_pic;
?>
<div class="container">	
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/user_photos/').$user_pic; ?>" width="100%"/>
	<form class="form-horizontal" id="user_info" action="<?php echo site_url('User/user_info'); ?>" method="post" enctype="multipart/form-data">
		<br/>
		<div class="form-group">
			<label class="error col-sm-offset-2"><?php echo $error; ?></label>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Uplode New Photo:</label>
			<div class="col-sm-10">
				<input type="file" class="form-control" name="pic" id="pic" required>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit">		
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Your Name:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_name; ?> </label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Your Nick Name:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_nick_name; ?> </label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Your Email:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_email; ?> </label>
			</div>
		</div>	
		<div class="form-group">
			<label class="control-label col-sm-2">Your Sex:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_sex; ?> </label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Your BOD:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_bod; ?> </label>
			</div>
		</div>	
		<div class="form-group">
			<label class="control-label col-sm-2">Your Phone Number:</label>
			<div class="col-sm-10">
				<label class="control-label user_de"> <?php echo $user_number; ?> </label>
			</div>
		</div>
	</form>	
</div>		
<?php $this->load->view('layouts/footer.php'); ?>