<?php defined('BASEPATH') OR exit('No direct script access allowed'); error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title> <?php echo $titel; ?> </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url('file/css/bootstrap1.css');?>">
  <script src="<?php echo base_url('file/js/jquery.js');?>"></script>
  <script src="<?php echo base_url('file/js/bootstrap.js');?>"></script>
</head>
<body>
	<div class="container">
	<div class="panel-group">
		<div class="panel panel-primary">
			<div class="panel-heading"> Admin Login </div>
			<div class="panel-body">
				<div class="form-group">
					<label class="error col-sm-offset-2"><?php echo $error; ?></label>
			    </div>
				<?php echo form_open('Kisu_admin', array('class' => 'form-horizontal')); ?>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email</label>
						<div class="col-sm-10">
					  		<?php echo form_input(array('id' => 'email', 'name' => 'email', 'class' => 'form-control', 'placeholder' => 'Enter your Email', 'value' => set_value('email')));?>
							<label class="error"><?php echo form_error('email'); ?></label>
						</div>
				  	</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Password</label>
						<div class="col-sm-10">
							<?php echo form_password(array('id' => 'password', 'name' => 'password', 'class' => 'form-control', 'placeholder' => 'Enter your Password'));?>
							<label class="error"><?php echo form_error('password'); ?></label>
						</div>
				  	</div>
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
					  		<?php echo form_submit(array('name' => 'submit', 'value' => 'Submit', 'class' => 'btn btn-primary')); ?>
						</div>
				  </div>
				<?php echo form_close(); ?> 
			</div>
		</div>
	</div>
</div>
</body>
</html>