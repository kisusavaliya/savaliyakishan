<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/side.css'); ?>" />

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a>My PHP Projects</a>
  <a href="<?php echo site_url('home/projects'); ?>">My .NET Projects</a>
</div>
<table width="100%">
	<tr>
		<td width="14%"> <div align="center"><span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> </div></td>
	  <td width="86%"> <h2 align="center"> My Projects in PHP </h2> </td>
	</tr>
</table>
<br>
<div class="home">
	<hr color="red" />	
	<p class="heading5"> 1.Online Hotel Management </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/hotel.jpg'); ?>" width="100%" >
	<hr color="red" />
	<p class="heading5"> 2.Online Shopping Management </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/shopping.png'); ?>" width="100%" >
	<hr color="red" />
	<p class="heading5"> 3.Online Doctor Appointment Management </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/doctor.png'); ?>" width="100%" >
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>	
<?php $this->load->view('layouts/footer.php'); ?>