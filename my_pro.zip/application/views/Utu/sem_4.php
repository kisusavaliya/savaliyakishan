<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('utu_layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<div class="table-responsive"> 
	<table class="table">
   		<tr>
			<th> Subjects </th>
			<th> All Practicals & All Units </th>
		</tr>
		<tr>
			<td> (030090401) Discrete Mathematics  </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090403) Computer Organization and Architecture </td>			
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td>  (030090405) Operating System </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090408) Microprocessor based System Design </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>	
		</tr>
		
		<tr>
			<td> (030090409) Management And Entrepreneurship </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090410) Computer Graphics </td>	
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
        <tr>
			<td> All Pepar </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
	</table> 
	</div>    		
</div>	
<?php $this->load->view('utu_layouts/footer.php'); ?>