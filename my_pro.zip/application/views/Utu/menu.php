<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<link rel="stylesheet" href="https://kendo.cdn.telerik.com/2018.1.117/styles/kendo.common-material.min.css" />
    <link rel="stylesheet" href="https://kendo.cdn.telerik.com/2018.1.117/styles/kendo.default.min.css" />
    <link rel="stylesheet" href="https://kendo.cdn.telerik.com/2018.1.117/styles/kendo.mobile.all.min.css" />

    <script src="https://kendo.cdn.telerik.com/2018.1.117/js/jquery.min.js"></script>
    <script src="https://kendo.cdn.telerik.com/2018.1.117/js/kendo.all.min.js"></script>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Computer Engineer</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li <?php if($menu === 'Home') { echo "class='active'"; } ?> >
			<a href="<?php echo site_url('Utu'); ?>">Home</a>
		</li>
        <li <?php if($menu === 'sem_1') { echo "class='active'"; } ?> >
			<a href="<?php echo site_url('Utu/sem_1'); ?>">Sem-1</a>
		</li>
        <li <?php if($menu === 'sem_2') { echo "class='active'"; } ?> >
			<a href="<?php echo site_url('Utu/sem_2'); ?>">Sem-2</a>
		</li>
		<li <?php if($menu === 'sem_3') { echo "class='active'"; } ?> >
			<a href="<?php echo site_url('Utu/sem_3'); ?>">Sem-3</a>
		</li>
		<li <?php if($menu === 'sem_4') { echo "class='active'"; } ?> >
			<a href="<?php echo site_url('Utu/sem_4'); ?>">Sem-4</a>
		</li>
      </ul>
    </div>
  </div>
</nav>