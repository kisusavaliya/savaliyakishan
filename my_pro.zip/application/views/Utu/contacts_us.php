<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('utu_layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<form class="form-horizontal info">
		<div class="form-group">
			<label class="control-label col-sm-2">Name:</label>
			<div class="col-sm-10"> <label class="control-label">Savaliya Kishan v.</label> </div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Email:</label>
			<div class="col-sm-10"> <label class="control-label">savaliyakishan0@gmail.com</label> </div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Phone:</label>
			<div class="col-sm-10"> <label class="control-label">98983 08252</label> </div>
		</div>	
		<div class="form-group">
			<label class="control-label col-sm-2">Devloped By:</label>
			<div class="col-sm-10"> <label class="control-label">Savaliya Kishan</label> </div>
		</div>
	</form>
	<hr color="red">
	<form action="<?php echo site_url('Contacts_us'); ?>" method="post" name="contacts_us" class="form-horizontal" id="contacts_us">	
		<div class="form-group">
			<label class="control-label col-sm-2">Name:</label>
			<div class="col-sm-10">
				<input type="name" class="form-control" name="name" id="name" placeholder="Enter your name" value="<?php echo @$_POST['name']; ?>" required>
				<label class="error"><?php echo form_error('name'); ?></label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Email:</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" value="<?php echo @$_POST['email']; ?>" required>
				<label class="error"><?php echo form_error('email'); ?></label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Phone:</label>
			<div class="col-sm-10">
				<input type="phone" class="form-control" name="phone_number" id="phone_number" placeholder="Enter your Phone number" value="<?php echo @$_POST['phone_number']; ?>" required>
				<label class="error"><?php echo form_error('phone_number'); ?></label>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Message:</label>
			<div class="col-sm-10">
				<textarea rows="5" class="form-control" id="message" name="message" placeholder="Enter Your Message" required></textarea>
				<label class="error"><?php echo form_error('message'); ?></label>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit" />
			</div>
		</div>
  </form>
  <script>
		$(document).ready(function()
		{					
			$("#contacts_us").validate(
			{
				rules: 
				{
					name:
					{
						required: true,
					},
					email:
					{
						required: true,
						email: true
					},
					phone:
					{
						required: true,
						minlength: 10,
						maxlength: 10,
					},
					message:
					{
						required: true,
					},
				}
			});
		});
	</script>
</div>	
<?php $this->load->view('utu_layouts/footer.php'); ?>