<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('utu_layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<div class="table-responsive"> 
	<table class="table">
   		<tr>
			<th> Subjects </th>
			<th> All Practicals & All Units </th>
		</tr>
		<tr>
			<td>  </td>
			<td> 
            	<a href="" target="_blank">
                	
            	</a>
            </td>
		</tr>
	</table> 
	</div>    		
</div>	
<?php $this->load->view('utu_layouts/footer.php'); ?>