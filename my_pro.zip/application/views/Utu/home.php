<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('utu_layouts/header.php'); 
error_reporting();
?>
<div class="container">	
	<div class="col-sm-6 col-mm-12">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/engine1/style.css'); ?>" />
		<script type="text/javascript" src="<?php echo base_url('file/engine1/jquery.js'); ?>"></script>
		<div id="wowslider-container1">
			<div class="ws_images">
				<ul>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/1.jpg'); ?>" alt="1" title="1" id="wows1_0"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/2.jpg'); ?>" alt="2" title="2" id="wows1_1"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/3.jpg'); ?>" alt="3" title="3" id="wows1_2"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/4.jpg'); ?>" alt="4" title="4" id="wows1_3"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/5.jpg'); ?>" alt="5" title="5" id="wows1_4"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/6.jpg'); ?>" alt="6" title="6" id="wows1_5"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/7.jpg'); ?>" alt="7" title="7" id="wows1_6"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/8.jpg'); ?>" alt="8" title="8" id="wows1_7"/></li>
					<li><img data-toggle="modal" data-src="<?php echo base_url('file/data1/images/9.jpg'); ?>" alt="9" title="9" id="wows1_8"/></li>
				</ul>
			</div>
			<div class="ws_bullets">
				<div>
					<a href="#" title="1"><span><img src="<?php echo base_url('file/data1/tooltips/1.jpg'); ?>" alt="1"/>1</span></a>
					<a href="#" title="2"><span><img src="<?php echo base_url('file/data1/tooltips/2.jpg'); ?>" alt="2"/>2</span></a>
					<a href="#" title="3"><span><img src="<?php echo base_url('file/data1/tooltips/3.jpg'); ?>" alt="3"/>3</span></a>
					<a href="#" title="4"><span><img src="<?php echo base_url('file/data1/tooltips/4.jpg'); ?>" alt="4"/>4</span></a>
					<a href="#" title="5"><span><img src="<?php echo base_url('file/data1/tooltips/5.jpg'); ?>" alt="5"/>5</span></a>
					<a href="#" title="6"><span><img src="<?php echo base_url('file/data1/tooltips/6.jpg'); ?>" alt="6"/>6</span></a>
					<a href="#" title="7"><span><img src="<?php echo base_url('file/data1/tooltips/7.jpg'); ?>" alt="7"/>7</span></a>
					<a href="#" title="8"><span><img src="<?php echo base_url('file/data1/tooltips/8.jpg'); ?>" alt="8"/>8</span></a>
					<a href="#" title="9"><span><img src="<?php echo base_url('file/data1/tooltips/9.jpg'); ?>" alt="9"/>9</span></a>
				</div>
			</div>	
			<script type="text/javascript" src="<?php echo base_url('file/engine1/wowslider.js'); ?>"></script>
			<script type="text/javascript" src="<?php echo base_url('file/engine1/script.js'); ?>"></script>
		</div>		
	</div>
	<div class="col-sm-6 col-mm-12" align="center">
		<hr>
		<div>
				<a href="https://drive.google.com/open?id=1xvxCa_jbzQE6Xs0E6SYS-wzmW3WRRArx" target="_blank"><img src="<?php echo base_url('file/images/apk.jpg'); ?>" height="60"/></a>
		</div>
		<hr>
		<table width="60%" align="center">
			<tr> 
				<td colspan="3" height="60"> <h3> Follow Me:- </h3></td>
			</tr>
			<tr> 
				<td>
					<a href="https://www.instagram.com/kisu_savaliya/"><img src="<?php echo base_url('file/images/insta.jpg'); ?>" height="60" width="60"/></a>
				</td>
				<td>
					<a href="https://www.facebook.com/kishan.savaliya.142"><img src="<?php echo base_url('file/images/fb.jpg'); ?>" height="60" width="60"/></a>
				</td>
				<td>	 
					<a href="https://twitter.com/savaliyakishan0"><img src="<?php echo base_url('file/images/tw.jpg'); ?>" height="60" width="60"/></a>
				</td>
				<td>	 
					<a href="https://www.youtube.com/channel/UCdYNwHnhm4BwwcHIyhYw59g?view_as=subscriber"><img src="<?php echo base_url('file/images/youtube.jpg'); ?>" height="60" width="60"/></a>
				</td>
			</tr>
		</table>
		<hr>
	</div>						
</div>
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>	
<?php $this->load->view('utu_layouts/footer.php'); ?>