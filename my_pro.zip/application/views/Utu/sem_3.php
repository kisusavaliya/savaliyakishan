<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('utu_layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<div class="table-responsive"> 
	<table class="table">
   		<tr>
			<th> Subjects </th>
			<th> All Practicals & All Units </th>
		</tr>
		<tr>
			<td> (030090305) Data and File Structure </td>
			<td> 
            	<a href="https://drive.google.com/drive/folders/0BwAmRMytqmnueUtDRkR5a1NBSkU?usp=sharing" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090306) Database Management System </td>			
			<td> 
            	<a href="https://drive.google.com/drive/folders/0BwAmRMytqmnuSFJWSDNUNG5SQlk?usp=sharing" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090308) Fundamentals of Linux </td>
			<td> 
            	<a href="" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090309) Engineering Mathematics - III </td>
			<td> 
            	<a href="https://drive.google.com/drive/folders/0BwAmRMytqmnuUnFrb3ZXd3YwTkk?usp=sharing" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>	
		</tr>
		<tr>
			<td> (030090310) Object Oriented Programming </td>	
			<td> 
            	<a href="https://drive.google.com/drive/folders/0BwAmRMytqmnualVoNGdkVkZLOEk?usp=sharing" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
		<tr>
			<td> (030090311) Digital Logic Design </td>
			<td> 
            	<a href="https://drive.google.com/drive/folders/0BwAmRMytqmnuanoxb2JocFc0QlU?usp=sharing" target="_blank">
                	<img data-toggle="modal" data-src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
        <tr>
			<td> All Pepar </td>
			<td> 
            	<a href="https://drive.google.com/drive/folders/1RLxM_uyh3Mdsp7mwB1DYD1ggR4Qm_RTl?usp=sharing" target="_blank">
                	<img src="<?php echo base_url('file/images/download.png'); ?>" width="40" height="40"> 
            	</a>
            </td>
		</tr>
	</table> 
	</div>    		
</div>	
<?php $this->load->view('utu_layouts/footer.php'); ?>