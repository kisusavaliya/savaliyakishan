<?php ?>	
	<form class="form-horizontal" id="user_info" action="<?php echo site_url('Home/files'); ?>" method="post" enctype="multipart/form-data">
		<br/>
		<div class="form-group">
			<label class="error col-sm-offset-2"><?php echo $error; ?></label>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Uplode New Photo:</label>
			<div class="col-sm-10">
				<input type="file" class="form-control" name="pic" id="pic" required>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit">		
			</div>
		</div>
	</form>		