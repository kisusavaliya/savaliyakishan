<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/side.css'); ?>" />

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="<?php echo site_url('Home'); ?>">My PHP Projects</a>
  <a>My .NET Projects</a>
</div>
<table width="100%">
	<tr>
		<td width="14%"> <div align="center"><span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> </div></td>
	  <td width="86%"> <h2 align="center"> My Projects in .NET </h2> </td>
	</tr>
</table>
<br>
<div class="home">
	<hr color="red" />	
	<p class="heading5"> 1.Online Hospital Management System </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/hospital.jpg'); ?>" width="100%" >
	<hr color="red" />
	<p class="heading5"> 2.Online Milk Product And Booking System </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/milk.jpg'); ?>" width="100%" >
	<hr color="red" />
	<p class="heading5"> 3.E-sport club system  </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/E-sport.jpg'); ?>" width="100%" >
	<hr color="red" />
	<p class="heading5"> 4.Enterprise Marketing System  </p>
	<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/Marketing.jpg'); ?>" width="100%" >
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>	
<?php $this->load->view('layouts/footer.php'); ?>