<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php');error_reporting(0);?>

<link rel="stylesheet" href="<?php echo base_url('file/css/jquery.lazyloadxt.spinner.css'); ?>">
<script src="<?php echo base_url('file/js/jquery.lazyloadxt.js') ?>"></script>
<script src="<?php echo base_url('file/js/jquery.session.js') ?>"></script>
<style>
.comm_table tr{
	height:50px;
}
</style>
<script>
function del(delete_comm)
{
	if(confirm("This Comment is delete") == true)
	{
		$.post("<?php echo site_url('Home/check_comment'); ?>",
		{	
			delete_id: delete_comm
		},
		function(data, status)
		{	
			$(".comm_table").html( data );
		});
	}
}	

$(document).ready(function()
{		
	var photo_name,like;
	
	photo_name = "cgpit";	
	
	$(".send").hide();
	$(".unlike").hide();
	$(".like").hide();
	
	$(".comment").keyup(function()
	{
		comm = $(".comment").val();
		if(isNaN(comm))
		{	
			$(".send").show();
		}
		else
		{
			$(".send").hide();	
		}	
	});
	
	$(".img").click(function()
	{
		var photo_id = $(this).attr("alt");
		$.session.set("photo_id", photo_id);
		
		$(".photo").attr("src","<?php echo base_url('file/images/friends/cgpit/'); ?>"+ photo_id +".jpg");
		check_like();
		check_comment();
		
	});
	
	$(".like").click(function()
	{
		$(".like").hide();
		$(".unlike").show();
		
		var likes = 1;
		check_like(likes);	
	});
	
	$(".unlike").click(function()
	{
		$(".unlike").hide();
		$(".like").show();
		
		var likes = 0;
		check_like(likes);
	});
	
	function check_like(likes)
	{
		$.post("<?php echo site_url('Home/check_likes'); ?>",
		{	
			likes: likes,
			photo_id: $.session.get("photo_id"),
			photo_name: photo_name
		},
		function(data, status)
		{	
			data = $.parseJSON( data );
			if(data.like === '1')
			{
				$(".unlike").show();
				$(".like").hide();
			}
			else
			{
				$(".like").show();
				$(".unlike").hide();
			}
			$(".like_user").text( data.like_list );	
		});	
	}
	
	$(".send").click(function()
	{	
		var comm = $(".comment").val();
		check_comment(comm);
		$(".comment").val("");
		$(".send").hide(); 
	});
	
	function check_comment(comm)
	{
		$.post("<?php echo site_url('Home/check_comment'); ?>",
		{	
			new_comment: comm
		},
		function(data, status)
		{	
			$(".comm_table").html( data );
		});	
	}
});		
</script>
<div class="grid container">
	<?php for($i=1; $i<=19; $i++) { ?>	
		<div class="grid-item">
			<img class="img" data-toggle="modal" data-target="#myModal" data-src="<?php echo base_url('file/images/friends/cgpit/t/'.$i.'.jpg'); ?>" alt="<?php echo $i; ?>">	
		</div>
	<?php } ?>	
</div> 
  
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        	<img class="photo" src="" width="100%"/>
        </div>
        <div class="modal-body">
			<table width="100%">
				<tr>
					<td class="likes" width="32%">
						 <a href="#"><img class="like" src="<?php echo base_url('file/images/like.png'); ?>" height="44px" width="90px" /></a>
						 <a href="#"><img class="unlike" src="<?php echo base_url('file/images/unlike.png'); ?>" height="44px" width="90px" /></a>
					</td>
					<td width="58%">
						<h2 style="color:#DC696C"> Like is :- </h2>
						<h3 style="color:#6B79F1" class="like_user"></h3>
					</td>
				</tr>
			</table>
			<hr color="red">
			<table width="100%" class="comm_table" >
				<tr>
					
				</tr>
			</table>	
			<hr color="red">		
			<table width="100%">
				<tr>
					<td> 
						<img src="<?php echo base_url('file/images/comment.png'); ?>" height="35px" width="35px" />
					</td>
					<td>	 
						<input type="text" id="comment" class="form-control comment" placeholder="Enter your Comment"/>	
					</td>
					<td>	
						<button class="send">
							<img src="<?php echo base_url('file/images/send.png'); ?>" height="30px" width="33px" />
						</button>
					</td>
				</tr>
			</table>
						
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>      
    </div>
  </div>
</div>
<?php $this->load->view('layouts/footer.php'); ?>