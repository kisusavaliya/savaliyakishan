<?php defined('BASEPATH') OR exit('No direct script access allowed'); error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $titel; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url('file/css/bootstrap1.css');?>">
  <script src="<?php echo base_url('file/js/jquery.js');?>"></script>
  <script src="<?php echo base_url('file/js/bootstrap.js');?>"></script>
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6655797245930949",
    enable_page_level_ads: true
  });
</script>
  <script>
	$(document).ready(function()
	{
		$("#freewha").hide();	
	});
</script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"> Kishan Admin </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li <?php if($menu === 'all_login') { echo "class='active'"; } ?>><a href="<?php echo site_url('Kisu_admin/home'); ?>">All Login</a></li>
        <li <?php if($menu === 'all_contacts') { echo "class='active'"; } ?>><a href="<?php echo site_url('Kisu_admin/all_contacts'); ?>">All Contacts</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo site_url('Kisu_admin/logout'); ?>"><span class=""></span> Logout </a></li>
      </ul>
    </div>
  </div>
</nav>	