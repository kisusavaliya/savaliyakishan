<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<h3 align="center"> My Brother in Comedy Videos </h3><br><hr>
<div align="center">
<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/cMptGtolTKM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
<h4> Gujju Valand (ગુજ્જુ વાળંદ) | Gujju Comedy video </h4>
<br>
<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/GOegpzEee48" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe><br>
<h4> Gujju keri valo (ગુજ્જુ કેરી વાળો) | Gujju Comedy video </h4>
<br>
<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/_WVOEhztWNE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
<h4> Love Status </h4>
<br>
<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/kRYLds1UjQA" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
<h4> Dil Aaj Kal love Status </h4>
</div>
<?php $this->load->view('layouts/footer.php'); ?>