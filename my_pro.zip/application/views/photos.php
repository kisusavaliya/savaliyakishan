<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<link href="<?php echo base_url('file/css/animate.css'); ?>" rel="stylesheet">
<script src="<?php echo base_url('file/js/jquery.lazyloadxt.js'); ?>"></script>
<style>
	.lazy-hidden {
    	opacity: 0;
        }
    </style>
<script>
	$.lazyLoadXT.onload = function() 
	{
		var $el = $(this);
		$el
		.removeClass('lazy-hidden')
		.addClass('animated ' + $el.attr('data-effect'));
  	};
</script>	
<div class="photos col-sm-12" align="center">
	<script>
        var category = 'animals',
            effects = ['tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig', 'tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig', 'tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig','tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig','tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig','tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig','tada', 'pulse', 'flipInX', 'flipInY', 'fadeIn', 'fadeInUp', 'fadeInRight', 'fadeInUpBig','fadeInRightBig','tada', 'pulse'];
        
		for(var i=0; i<effects.length; i++) {
            document.write('<img data-src="<?php echo base_url('file/images/my_pic/'); ?>' + (1+(i%16)) +'.jpg' +'" data-effect="' + effects[i] + '" width="100%">');
        }
    </script>
</div>	
<?php $this->load->view('layouts/footer.php'); ?>