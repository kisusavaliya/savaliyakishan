<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<form class="form-horizontal" id="reset_pass" action="<?php echo site_url('User/reset_pass'); ?>" method="post">
		<div class="form-group">
			<label class="error col-sm-offset-2"><?php echo $error;?></label>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Nick Name:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" name="nick_name" id="nick_name" placeholder="Enter your nick name" value="<?php echo @$_POST['nick_name']; ?>" required>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Email:</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" value="<?php echo @$_POST['email']; ?>" required>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">New Password:</label>
			<div class="col-sm-10">
				<input type="password" class="form-control" name="password" id="password" placeholder="Enter your new password" value="<?php echo @$_POST['password']; ?>" required>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit">
				<a href="<?php echo site_url('User');?>"> <input type="button" class="btn btn-danger" name="login" value="Login"></a>
			</div>
		</div>
	</form>
	<script>
		$(document).ready(function()
		{					
			$("#reset_pass").validate(
			{
				rules: 
				{
					email:
					{
						required: true,
						email: true,
					},
					nick_name:
					{
						required: true,
					},
					password:
					{
						required: true,
						password: "required",
						minlength: 6,
					},
				}
			});
		});
	</script>		
</div>		
<?php $this->load->view('layouts/footer.php'); ?>