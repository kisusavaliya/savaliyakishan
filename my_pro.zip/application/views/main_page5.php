<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<link rel="stylesheet" href="<?php echo base_url('file/css/jquery.lazyloadxt.spinner.css'); ?>">
	<script src="<?php echo base_url('file/js/jquery.lazyloadxt.js') ?>"></script>
	<script>
		var category = 'city';
		for(var i=0; i<=59; i++) {
			document.write('<p><img data-src="<?php echo base_url('file/images/friends/ekata/'); ?>' + (1+(i%60)) +'.jpg' +'" width="100%"></p>');
		}
	</script>
</div>	
<?php $this->load->view('layouts/footer.php'); ?>