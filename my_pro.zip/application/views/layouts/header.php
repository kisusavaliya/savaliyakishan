<?php defined('BASEPATH') OR exit('No direct script access allowed'); error_reporting(0); 
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
	<title> <?php echo $titel; ?> </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="shortcut icon" href="<?php echo base_url('file/images/gt_favicon.png'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/bootstrap.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/normalize.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/component1.css'); ?>" />
	
	<script type="text/javascript" src="<?php echo base_url('file/js/modernizr-2.6.2.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/jquery.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/bootstrap.js'); ?>"></script>
	<script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
	<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-7243260-2']);
	_gaq.push(['_trackPageview']);
	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
	</script>
	<script>
		$(document).ready(function()
		{
			$('[alt="Free Web Hosting"]').hide();	
		});
    </script>
</head>
<body>
<link rel="stylesheet" href="<?php echo base_url('file/css/jquery.lazyloadxt.spinner.css'); ?>">
<script src="<?php echo base_url('file/js/jquery.lazyloadxt.js') ?>"></script>
<script src="<?php echo base_url('file/js/jquery.session.js') ?>"></script>
<div>
	<div class="heading1">
		<table width="100%">
			<tr align="center"> 
				<td align="center">  
					<img class="heading4" src="<?php echo base_url('file/images/gt_favicon.png'); ?>" height="59" width="59">
				</td>
				<td align="center">
					<a href="<?php echo site_url('Home'); ?>"> <p class="heading3"> Savaliya Kishan </p> </a>
				</td>
				<td align="center">
					<img class="heading4" src="<?php echo base_url('file/images/gt_favicon.png'); ?>" height="59" width="59">
				</td>
			</tr>
		</table>			
	</div>
	<div>
		<table width="100%">
			<tr align="center"> 
				<td align="center"> <p class="heading2"> <?php echo $head_titel; ?> </p> </td>			
				<?php if($menu === 'cgpit_login') { if($_SESSION['cgpit_login'] === 'ok') { ?>
				<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/my_menu.css'); ?>" />
				<div class="topnav" id="myTopnav">
				  <a href="<?php echo site_url('D2d/D2d_student') ?>">Student Orientation</a>
				  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onClick="myFunction()">&#9776;</a>
				</div>
				<?php } } ?>	
				
				<?php if($menu === 'main_login') { if($_SESSION['main_login'] === 'ok') { ?>
				<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/my_menu.css'); ?>" />
				<div class="topnav" id="myTopnav">
				  <a href="<?php echo site_url('Home/main_page') ?>">Visit 1</a>
				  <a href="<?php echo site_url('Home/main_page2') ?>">Visit 2</a>
				  <a href="<?php echo site_url('Home/main_page3') ?>">Black Day</a>
				  <a href="<?php echo site_url('Home/main_page4') ?>">Ekata Marriage</a>
				  <a href="<?php echo site_url('Home/main_page5') ?>">All Videos</a>
				  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onClick="myFunction()">&#9776;</a>
				</div>
				<?php } } else { ?>	
					<?php if($menu === 'user_info') { ?>
						<td align="center"> <a href="<?php echo base_url('Home'); ?>" ><p class="my_pro"> <span class='icon-step-backward'></span> Back </p></a> </td>
						<td align="center"> <a href="<?php echo base_url('D2d'); ?>" ><p class="my_pro"> Friends D 2 D </p></a> </td>
						<td align="center"> <a href="<?php echo base_url('Home/main_login'); ?>" ><p class="my_pro"> Main Login </p></a> </td>
					<?php } else { if(isset($_SESSION['user_email'])) { ?>
						<td align="center"> <a href="<?php echo base_url('User/user_info'); ?>" ><p class="my_pro"> User Info </p></a> </td> </td>
					<?php } } ?>
					<?php if($menu === 'contacts_us' || $menu === 'user_info' || $menu === 'cgpit_login') { }else { if(isset($_SESSION['user_email'])) { ?>
						<td align="center"> <a href="<?php echo base_url('Contacts_us'); ?>" ><p class="my_pro"> Download My Project </p></a> </td>
					<?php } } ?>
				<?php } ?>
			</tr>
	  </table>
		
		<hr color="red">
	</div>	