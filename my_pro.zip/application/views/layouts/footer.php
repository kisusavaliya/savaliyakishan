<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<div class="component">
	<!-- Start Nav Structure -->
		<button class="cn-button" id="cn-button">+</button>
		<div class="cn-wrapper" id="cn-wrapper">
			<ul>
				<li <?php if($menu === 'contacts_us'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Contacts_us');?>"><span class="icon-envelope"></span></a></li>
				<li <?php if($menu === 'photos'){ echo "class='active'"; } ?>><a href="<?php echo site_url('My_gallery');?>"><span class="icon-picture"></span></a></li>
				<li <?php if($menu === 'home'){ echo "class='active'"; } ?>><a href="<?php echo site_url('Home');?>"><span class="icon-home"></span></a></li>
				<li <?php if($menu === 'videos'){ echo "class='active'"; } ?>><a href="<?php echo site_url('My_gallery/videos');?>"><span class="icon-facetime-video"></span></a></li>
				<?php
				if($_SESSION['user_email']){
					echo "<li><a href='".site_url('User/logout')."'><span class='icon-signout'></span></a></li>";
				}else{
					if($menu === 'login'){
						echo "<li class='active'><a href='".site_url('User/index')."'><span class='icon-signin'></span></a></li>";	
					}else{
						echo "<li><a href='".site_url('User/index')."'><span class='icon-signin'></span></a></li>";	
					}
				}
				?>
			</ul>
		</div>
		<div id="cn-overlay" class="cn-overlay"></div>
	<!-- End Nav Structure -->
	</div>
	<hr color="red">
	<div class="col-sm-12 col-mm-12" align="left">
		<div class="col-sm-6 col-mm-6">
			<p class="footer_font">Devloped By:~ Savaliya Kishan </p>
		</div>
		<div class="col-sm-6 col-mm-6" align="right">
			<a href="https://drive.google.com/open?id=1xvxCa_jbzQE6Xs0E6SYS-wzmW3WRRArx" target="_blank"><img src="<?php echo base_url('file/images/apk.jpg'); ?>" height="50"/></a>
		</div>	
	</div>
	<table width="100%">
		<tr align="center"> 
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
			<td align="center"> <a href="#">  </a> </td>
		</tr> 
	</table>
</div><!-- /container -->	
<div style="height:45px"></div>
<script src="<?php echo base_url('file/js/polyfills.js'); ?>"></script>
<script src="<?php echo base_url('file/js/demo1.js'); ?>"></script>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<!-- For the demo ad only -->   
</body>
</html>