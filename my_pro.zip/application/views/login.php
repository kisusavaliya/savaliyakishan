<?php defined('BASEPATH') OR exit('No direct script access allowed'); $this->load->view('layouts/header.php'); 
error_reporting(0);
?>
<div class="container">	
	<form class="form-horizontal" id="login" action="<?php echo site_url('User'); ?>" method="post">
		<div class="form-group">
			<label class="error col-sm-offset-2"><?php echo $error; echo $_SESSION['Msg']; unset($_SESSION['Msg']); ?></label>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Email:</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" value="<?php echo @$email; ?>" required>
			</div>
		</div>
		<div class="form-group">
			<label class="control-label col-sm-2">Passowrd:</label>
			<div class="col-sm-10">
				<input type="password" class="form-control" name="password" id="password" placeholder="Enter your passowrd" value="<?php echo @$passowrd; ?>" required>
			</div>
		</div>
		<div class="form-group"> 
			<div class="col-sm-offset-2 col-sm-10">
				<input type="submit" class="btn btn-danger" name="submit" value="Submit">
				<a href="<?php echo site_url('User/sign_up');?>"> <input type="button" class="btn btn-danger" name="sign_up" value="New User"></a> 
				
			</div>
		</div>
		<div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
				<h5> click <a href="<?php echo base_url('User/reset_pass'); ?>">here </a> to reset your password. </h5>
			</div>	
		</div>
	</form>
	<script>
		$(document).ready(function()
		{					
			$("#login").validate(
			{
				rules: 
				{
					email:
					{
						required: true,
						email: true
					},
					password:
					{
						required: true,
						password: "required",
					},
				}
			});
		});
	</script>				
</div>		
<?php $this->load->view('layouts/footer.php'); ?>