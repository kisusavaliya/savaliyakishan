<html lang="en" class="no-js">
<head>
	<title> <?php echo $titel; ?> </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="shortcut icon" href="<?php echo base_url('file/images/gt_favicon.png'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/bootstrap1.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/normalize.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('file/css/component1.css'); ?>" />
	
	<script type="text/javascript" src="<?php echo base_url('file/js/modernizr-2.6.2.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/jquery.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('file/js/bootstrap.js'); ?>"></script>
	
<script async="async" src="https://www.google.com/adsense/search/ads.js"></script>

<!-- other head elements from your page -->

<script type="text/javascript" charset="utf-8">
(function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(
  arguments)},g[o]['t']=1*new Date})(window,'_googCsa');
</script>

	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
	  (adsbygoogle = window.adsbygoogle || []).push({
		google_ad_client: "ca-pub-6655797245930949",
		enable_page_level_ads: true
	  });
	</script>
<script>
	$(document).ready(function()
	{
		$("#freewha").hide();	
	});
</script>
</head>
<body>
	<h1> Savaliya kishan </h1>
<div id='afscontainer1'></div>

<script type="text/javascript" charset="utf-8">

  var pageOptions = {
    "pubId": "pub-9616389000213823", // Make sure this the correct client ID!
    "query": "hotels",
    "adPage": 1,
    "adtest": "on"
  };

  var adblock1 = {
    "container": "afscontainer1",
    "width": "700",
    "number": 2,
    "longerHeadlines": true
  };

  _googCsa('ads', pageOptions, adblock1);

</script>
</body>
</html>		