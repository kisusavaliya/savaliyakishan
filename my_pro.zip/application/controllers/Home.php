<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{
	public function index()
	{
		if(!isset($_SESSION['user_email']))
		{
			redirect('User');
		}
		else
		{
			$data['titel'] = "Kishan | Home";
			$data['menu'] = "home";
			$data['head_titel'] = "Home";
			$this->load->view('home',$data);
		}	
	}
	
	public function projects()
	{
		if(!isset($_SESSION['user_email']))
		{
			redirect('User');
		}
		else
		{
			$data['titel'] = "Kishan | Home";
			$data['menu'] = "home";
			$data['head_titel'] = "Home";
			$this->load->view('home1',$data);
		}
	}
	
	function files()
	{
		$config = array(
			'upload_path' => './file/images/friends/visit2/',
			'file_name' => time()
		);	
						
		$this->load->library('upload', $config);
				
				
		if (!$this->upload->do_upload('pic'))
		{
			$data['error'] = $this->upload->display_errors();
			$this->load->view('files',$data);
		}
		else
		{
			echo "sdasdasd";
			$this->load->view('files');
		}	
	}
	
	public function main_login()
	{
		if(!isset($_SESSION['user_email']))
		{
			redirect('User');
		}
		else
		{
			if(isset($_SESSION['main_login']) == 'ok')
			{
				redirect('Home/main_page');
			}
			else
			{
				if($this->input->post())  
				{
					$this->db->where('name', $this->input->post('name'));
					$this->db->where('password', $this->input->post('password'));
					$res = $this->db->get('main_login');
					
					if( $res->num_rows() > 0 )  
					{
						$user = $res->row_array();
						
						$_SESSION['main_login'] = 'ok';				
						redirect('Home/main_page');
					}	
					else	
					{
						$data = $this->input->post();
						$data['error'] = "Email and Password invalid.";
					}
				}	
				
				$data['titel'] = "Kishan | Main Login";
				$data['menu'] = "main_login";
				$data['head_titel'] = "Main Login";
				$this->load->view('main_login',$data);
			}	
		}	
	}
	
	public function check_likes()
	{
		$_SESSION['photo_id'] = $_REQUEST['photo_id'];
		$_SESSION['photo_name'] = $_REQUEST['photo_name'];
		
		if(isset($_REQUEST['likes']))
		{
			if($_REQUEST['likes'] == 0)
			{
				$datas = array( 'like' => 0);
				$data['like'] = '0';
			}
			else
			{
				$datas = array( 'like' => 1);
				$data['like'] = '1';
			}
			
			$check_like = $this->Model->check_like();
			if(!$check_like)
			{
				$datas = array(
					'user_id' => $_SESSION['user_id'],
					'photo_id' => $_SESSION['photo_id'],
					'photo_name' => $_SESSION['photo_name'],
					'like' => $data['like']
				);
				
				$this->Model->new_like($datas);
			}
			else
			{
				$this->Model->up_like($datas);
			}
		}
		else
		{
			$this->db->where('user_id', $_SESSION['user_id']);
			$this->db->where('photo_id', $_SESSION['photo_id']);
			$this->db->where('photo_name', $_SESSION['photo_name']);
			$res = $this->db->get('photo_like');
			
			if($res->num_rows() > 0)
			{
				$user = $res->row()->like;
				$data['like'] = $user;
			}
			else
			{
				$data['like'] = '0';
			}
		}
		$like_lists = $this->Model->like_list();
		$data['like_list'] = implode(", ",$like_lists);			
		echo json_encode($data);	
	}
	
	public function check_comment()
	{	
		if(isset($_REQUEST['new_comment']))
		{
			$data = array(
				'user_id' => $_SESSION['user_id'],
				'photo_id' => $_SESSION['photo_id'],
				'photo_name' => $_SESSION['photo_name'],
				'comment' => $_REQUEST['new_comment']
			);
			
			$new_comm = $this->Model->new_comm($data);
		}
		
		if(isset($_REQUEST['delete_id']))
		{
			$data = $_REQUEST['delete_id'];
			$this->Model->delete_comm($data);
		}
		
		$comm_data = $this->Model->comm();
		
		
		if($comm_data == NULL)
		{
			echo "
				  <tr>
					<td class='user_pic' width='15%' colspan='2'> 
						<h4> No Comment Found. </h4>
					</td>
				  </tr>
				 ";
		}
		else
		{
			echo "<tr>
					<td  width='15%' colspan='2'><h2 style='color:#DC696C'>  Comment :- </h2> </td>
				  </tr>";
			foreach($comm_data as $data)
			{
				$delete_comm = $data['comment_id']; 
				echo "
						<tr>
							<td class='user_pic' width='20%'> 
								<img class='user_photos' src='"; echo base_url('file/images/user_photos/').$data['user_pic']; echo"' height='55px' width='55px' /> 
							</td>
							<td width=''>
								<h3 style='color:#DC696C'><b>". $data['user_name']." :- </b></h3>
								<h4 class='comment_list' style='color:#6B79F1'> ".$data['comment']." </h4> 
							</td>
							<td class='delete' width='9%' align='right'> "; 
								
								if($_SESSION['user_id'] == $data['user_id'])
								{
									echo "<button onclick='javascript:del($delete_comm)' name='$delete_comm'> <img src='"; echo base_url('file/images/delete.jpg'); echo "' height='20px' width='20px' /></button>";
								}
								echo "	
							</td>
						</tr>
					 "; 
			}			
		}
	}
	
	public function notification()
	{
		$noti_comm = $this->Model->noti_comm();
		echo "<pre>";
		print_r($noti_comm);
		echo "</pre>";
		die();
	}
	
	public function main_page()
	{
		if(!isset($_SESSION['main_login']))
		{
			redirect('Home/main_login');
		}
		else
		{
			$data['titel'] = "Kishan | Visit 1";
			$data['menu'] = "main_login";
			$data['head_titel'] = "4 Sem ( Visit 1 )";
			$this->load->view('main_page',$data);
		}
	}
	
	public function main_page2()
	{
		if(!isset($_SESSION['main_login']))
		{
			redirect('Home/main_login');
		}
		else
		{
			$data['titel'] = "Kishan | Visit 2";
			$data['menu'] = "main_login";
			$data['head_titel'] = "5 Sem ( Visit 2 )";
			$this->load->view('main_page2',$data);
		}
	}
	
	public function main_page3()
	{
		if(!isset($_SESSION['main_login']))
		{
			redirect('Home/main_login');
		}
		else
		{	
			$data['titel'] = "Kishan | Black Day";
			$data['menu'] = "main_login";
			$data['head_titel'] = "Black Day";
			$this->load->view('main_page3',$data);
		}
	}
	
	public function main_page4()
	{
		if(!isset($_SESSION['main_login']))
		{
			redirect('Home/main_login');
		}
		else
		{
			$data['titel'] = "Kishan | Ekata Marriage";
			$data['menu'] = "main_login";
			$data['head_titel'] = "Ekata Marriage";
			$this->load->view('main_page4',$data);
		}
	}
	
	public function main_page5()
	{
		if(!isset($_SESSION['main_login']))
		{
			redirect('Home/main_login');
		}
		else
		{
			$data['titel'] = "Kishan | All Videos";
			$data['menu'] = "main_login";
			$data['head_titel'] = "All Videos";
			$this->load->view('main_page5',$data);
		}
	}
}
