<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Utu extends CI_Controller 
{
        public function Kishan()
	{
		$data['titel'] = "Kishan | Home";
		$data['menu'] = "Home";
		$data['head_titel'] = "Home";
		$this->load->view('Kishan',$data);
	}	
        public function Index()
	{
		$data['titel'] = "Kishan | Home";
		$data['menu'] = "Home";
		$data['head_titel'] = "Home";
		$this->load->view('Utu/home',$data);
	}
	
	public function sem_1()
	{
		$data['titel'] = "Kishan | Sem-1";
		$data['menu'] = "sem_1";
		$data['head_titel'] = "Sem - 1";
		$this->load->view('Utu/sem_1',$data);
	}
	
	public function sem_2()
	{
		$data['titel'] = "Kishan | Sem-2";
		$data['menu'] = "sem_2";
		$data['head_titel'] = "Sem - 2";
		$this->load->view('Utu/sem_2',$data);
	}
	
	public function sem_3()
	{
		$data['titel'] = "Kishan | Sem-3";
		$data['menu'] = "sem_3";
		$data['head_titel'] = "Sem - 3";
		$this->load->view('Utu/sem_3',$data);
	}
	
	public function sem_4()
	{
		$data['titel'] = "Kishan | Sem-4";
		$data['menu'] = "sem_4";
		$data['head_titel'] = "Sem - 4";
		$this->load->view('Utu/sem_4',$data);
	}
	
	public function photos()
	{
		$data['titel'] = "Kishan | My Photos";
		$data['menu'] = "photos";
		$data['head_titel'] = "My Photos";
		$this->load->view('Utu/photos',$data);
	}
	
	public function videos()
	{
		$data['titel'] = "Kishan | My Videos";
		$data['menu'] = "videos";
		$data['head_titel'] = "My videos";
		$this->load->view('Utu/videos',$data);
	}
	
	public function down_apk()
	{
		$this->load->helper('download');
		force_download('BTech.apk', base_url('file/BTech.apk'));
	}

	public function contacts_us()
	{
		if(isset($_POST['submit']))
		{		
			$post_data = array(
				'name' => $this->security->sanitize_filename($this->input->post('name')),
				'email' => $this->security->sanitize_filename($this->input->post('email')),
				'phone' => $this->security->sanitize_filename($this->input->post('phone_number')),
				'message' => $this->security->sanitize_filename($this->input->post('message')),
			);
			
			$datas = $this->Model->contacts_us($post_data);
			redirect('Utu');	
		}
		else
		{
			$data['titel'] = "Kishan | Contacts Us";
			$data['menu'] = "contacts_us";
			$data['head_titel'] = "Contacts Us";
			$this->load->view('Utu/contacts_us',$data);
		}
	}
}
	