<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class My_home extends CI_Controller 
{
	public function Index()
	{
		$data['titel'] = "Kishan | Home";
		$data['menu'] = "home";
		$data['head_titel'] = "Home";
		$this->load->view('my_home',$data);
	}
}
