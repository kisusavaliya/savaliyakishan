<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller 
{
	public function index()
	{	
		if(isset($_SESSION['user_email']))
		{
			redirect('Home');
		}
		else
		{
			if($this->input->post())  
			{
				$this->db->where('user_email', $this->input->post('email'));
				$this->db->where('user_password', $this->input->post('password'));
				$res = $this->db->get('user_login');
				
				if( $res->num_rows() > 0 )  
				{
					$user = $res->row_array();
					
					$_SESSION['user_email'] = $user['user_email'];
					$_SESSION['user_id'] = $user['user_id'];				
					redirect('Home');
				}	
				else	
				{
					$data = $this->input->post();
					$data['error'] = "Email and Password invalid.";
				}
			}	
				
			$data['titel'] = "Kishan | User Login";
			$data['menu'] = "login";
			$data['head_titel'] = "User Login";
			$this->load->view('login',$data);
		}	
	}
	
	public function sign_up()
	{
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('nick_name', 'Nick Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user_login.user_email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('sex', 'Sex', 'required');
		$this->form_validation->set_rules('phone_number', 'Phone Number','required|min_length[10]|max_length[10]|integer');
		
		if ($this->form_validation->run() == FALSE)
        {
			$data['titel'] = "Kishan | User Sign-up";
			$data['menu'] = "login";
			$data['head_titel'] = "User Sign-up";
			$this->load->view('sign_up',$data);
        }
        else
        {
			$config = array(
				'allowed_types' => 'gif|jpg|jpeg|png',
				'upload_path' => './file/images/user_photos/',
				'file_name' => time()
			);	
					
			$this->load->library('upload', $config);
					
			if (!$this->upload->do_upload('pic'))
            {
				$data['pic_error'] = $this->upload->display_errors();
				$data['titel'] = "Kishan | User Sign-up";
				$data['menu'] = "login";
				$data['head_titel'] = "User Sign-up";
				$this->load->view('sign_up',$data);
            }
            else
            {
            	$datas = $this->upload->data();
				$file_name = $datas['file_name'];
				
				$post_data = array(
					'user_name' => $this->security->sanitize_filename($this->input->post('name')),
					'user_nick_name' => $this->security->sanitize_filename($this->input->post('nick_name')),
					'user_email' => $this->security->sanitize_filename($this->input->post('email')),
					'user_password' => $this->security->sanitize_filename($this->input->post('password')),
					'user_sex' => $this->security->sanitize_filename($this->input->post('sex')),
					'user_bod' => $this->security->sanitize_filename($this->input->post('bod')),
					'user_number' => $this->security->sanitize_filename($this->input->post('phone_number')),
					'user_pic' => $file_name,
				);
				
				$datas = $this->User_model->sign_up($post_data);				
				redirect('User');	
            }
		}
	}
	
	public function reset_pass()
	{
		if(isset($_POST['submit']))
		{	
			$this->db->where('user_nick_name', $this->input->post('nick_name'));
			$this->db->where('user_email', $this->input->post('email'));
			$res = $this->db->get('user_login');
			
			if( $res->num_rows() > 0 )  
			{
				$user = $res->row_array();
				
				$email = $user['user_email'];
				$post_data = array('user_password' => $this->input->post('password'));
				
				$datas = $this->User_model->reset_pass($email,$post_data);
				if($datas)
				{
					redirect('User');	
				}
			}	
			else	
			{
				$data = $this->input->post();
				$data['error'] = "Your Email and Nick name is invalid.";
			}
		}
		$data['titel'] = "Kishan | Reset Password";
		$data['menu'] = "login";
		$data['head_titel'] = "User Reset Password ";
		$this->load->view('reset_pass',$data);
	}
	
	public function user_info()
	{	
		if(!isset($_SESSION['user_email']))
		{
			redirect('User');	
		}
		else
		{
			if(isset($_POST['submit']))
			{
				$config = array(
				'allowed_types' => 'gif|jpg|jpeg|png',
				'upload_path' => './file/images/user_photos/',
				'file_name' => time()
				);	
						
				$this->load->library('upload', $config);
				
				
				if (!$this->upload->do_upload('pic'))
				{
					$data['error'] = $this->upload->display_errors();
					$data = $this->User_model->user_info($email = array('user_email' => $_SESSION['user_email']));
					$data['titel'] = "Kishan | User Info";
					$data['menu'] = "user_info";
					$data['head_titel'] = "User Info ";
					$this->load->view('user_info',$data,$data);
				}
				else
				{
					
					$datas = $this->upload->data();
					$file_name = $datas['file_name'];
					unlink("./file/images/user_photos/".$_SESSION['user_pic']);
					
					$email = array('user_email' => $_SESSION['user_email']);
					$post_data = array( 'user_pic' => $file_name );				
					$datas = $this->User_model->user_new_pic($email,$post_data);
							
					redirect('Home');
				}
			}
			else
			{			
				$data = $this->User_model->user_info($email = array('user_email' => $_SESSION['user_email']));
				$data['titel'] = "Kishan | User Info";
				$data['menu'] = "user_info";
				$data['head_titel'] = "User Info ";
				$this->load->view('user_info',$data,$data);	
			}	
		}
	}
	
	public function emails()
	{
		$this->load->library('email');

	}

	public function logout()
	{
		session_destroy();
		redirect('');
	}
}
