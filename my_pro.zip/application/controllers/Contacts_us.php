<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Contacts_us extends CI_Controller 
{
	public function index()
	{	
		if(isset($_POST['submit']))
		{		
			$post_data = array(
				'name' => $this->security->sanitize_filename($this->input->post('name')),
				'email' => $this->security->sanitize_filename($this->input->post('email')),
				'phone' => $this->security->sanitize_filename($this->input->post('phone_number')),
				'message' => $this->security->sanitize_filename($this->input->post('message')),
			);
			
			$datas = $this->Model->contacts_us($post_data);
			redirect('Home');	
		}
		else
		{
			$data['titel'] = "Kishan | Contacts Us";
			$data['menu'] = "contacts_us";
			$data['head_titel'] = "Contacts Us";
			$this->load->view('contacts_us',$data);
		}	
	}
}
