<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class D2d extends CI_Controller 
{	
	public function index()
	{
		if(!isset($_SESSION['user_email']))
		{
			redirect('User');
		}
		else
		{
			if(isset($_SESSION['cgpit_login']) == 'ok')
			{
				redirect('D2d/D2d_student');
			}
			else
			{
				if($this->input->post())  
				{
					$this->db->where('name', $this->input->post('name'));
					$this->db->where('password', $this->input->post('password'));
					$res = $this->db->get('d2d');
					
					if( $res->num_rows() > 0 )  
					{
						$user = $res->row_array();
						
						$_SESSION['cgpit_login'] = 'ok';				
						redirect('D2d/D2d_student');
					}	
					else	
					{
						$data = $this->input->post();
						$data['error'] = "Email and Password invalid.";
					}
				}	
				
				$data['titel'] = "Kishan | Cgpit Login";
				$data['menu'] = "main_login";
				$data['head_titel'] = "Cgpit Friends";
				$this->load->view('cgpit_login',$data);
			}	
		}	
	}
	
	public function D2d_student()
	{
		if(!isset($_SESSION['cgpit_login']))
		{
			redirect('D2d');
		}
		else
		{
			$data['titel'] = "Kishan | Orientation";
			$data['menu'] = "cgpit_login";
			$data['head_titel'] = "Student Orientation";
			$this->load->view('cgpit1',$data);
		}
	}
}