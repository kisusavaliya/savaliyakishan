<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Kisu_admin extends CI_Controller 
{
	public function index()
	{
		if(isset($_SESSION['admin_email']))
		{
			redirect('Kisu_admin/home');
		}
		else
		{
			if($this->input->post())  
			{
				$this->db->where('email', $this->input->post('email'));
				$this->db->where('password', md5($this->input->post('password')));
				$res = $this->db->get('admin_login');
					
				if( $res->num_rows() > 0 )  
				{
					$user = $res->row_array();
					
					$_SESSION['admin_email'] = $user['email'];				
					redirect('Kisu_admin/home');
				}	
				else	
				{
					$data = $this->input->post();
					$data['error'] = "Email and Password invalid.";
				}
			}
			$data['titel'] = "Admin | Login";
			$this->load->view('ad_login',$data);
		}	
	}
	
	public function home()
	{
		if(!isset($_SESSION['admin_email']))
		{
			redirect('home');
		}
		else
		{
			$data['datas'] = $this->db->get('user_login')->result();		
			
			$data['titel'] = "Admin | All Login";
			$data['menu'] = "all_login";
			$this->load->view('ad_home',$data);
		}	
	}
	
	public function all_contacts()
	{
		if(!isset($_SESSION['admin_email']))
		{
			redirect('home');
		}
		else
		{
			$data['datas'] = $this->db->get('contacts_us')->result();
			$data['titel'] = "Admin | All contacts";
			$data['menu'] = "all_contacts";
			$this->load->view('ad_contacts',$data);
		}	
	}
	
	public function logout()
	{
		unset($_SESSION['admin_email']);
		redirect('home');
	}
}
