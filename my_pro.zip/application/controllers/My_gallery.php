<?php
session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class My_gallery extends CI_Controller 
{
	public function index()
	{
		if(isset($_SESSION['user_email']))
		{
			$data['titel'] = "Kishan | My Photos";
			$data['menu'] = "photos";
			$data['head_titel'] = "My Photos";
			$this->load->view('photos',$data);
		}
		else
		{
			$_SESSION['Msg'] = "Login Please.";
			redirect('User');
		}
	}
	
	public function videos()
	{
		$data['titel'] = "Kishan | My Videos";
		$data['menu'] = "videos";
		$data['head_titel'] = "My videos";
		$this->load->view('videos',$data);
	}
}
